---
id: repo-auditor
name: Auditor de repositorio (read-only)
allowed-tools:
  - fs.read
  - git.status
  - git.diff
scripts:
  dry-run: node scripts/plan.js
  run: node scripts/run.js
---

# Auditor de repositorio (read-only)

Inspecciona estructura y estado del repositorio sin modificar nada.

## Qué hace
- Reporta `git status` (porcelain).
- Reporta `git diff` (sin color, unified=0).

## Límites
- No realiza cambios. Solo lectura.

