# Skills Fabric CLI

<div align="center">

[![npm version](https://badge.fury.io/js/%40skills-fabrik%2Fskills-cli.svg)](https://badge.fury.io/js/%40skills-fabrik%2Fskills-cli)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3+-blue)](https://www.typescriptlang.org/)

**Universal CLI for skills, workflows, and development automation with slash commands**

[Installation](#installation) • [Quick Start](#quick-start) • [Commands](#available-commands) • [Claude Code Integration](#claude-code-integration) • [Examples](#examples)

</div>

## Overview

Skills Fabric CLI provides powerful slash commands that work universally across any project. Whether you're working in a Skills Fabric repository or any other project, our hybrid system delivers consistent development automation with zero configuration required.

### 🌟 Key Features

- **🔄 Hybrid Architecture**: Full workspace mode in Skills Fabric repos, standalone mode everywhere else
- **🚀 Zero Configuration**: Works immediately after installation
- **⚡ Slash Commands**: Intuitive command syntax for common development tasks
- **🌐 Universal**: Works in any repository, any project, any framework
- **🤖 Claude Code Integration**: Native support for Claude Code environments
- **📦 Lightweight**: Minimal dependencies, fast startup
- **🛡️ Type Safe**: Built with TypeScript for reliability

## Installation

### Global Installation (Recommended)

```bash
npm install -g @skills-fabrik/skills-cli
```

### Alternative Installation Methods

```bash
# Using yarn
yarn global add @skills-fabrik/skills-cli

# Using pnpm
pnpm add -g @skills-fabrik/skills-cli

# Using npx (no installation needed)
npx @skills-fabrik/skills-cli / list
```

### Verify Installation

```bash
skills-cli / list
```

## Quick Start

### 1. List Available Commands

```bash
skills-cli / list
```

### 2. Run Your First Command

```bash
# Auto-build, lint, and fix project issues
skills-cli / build-and-fix

# Perform comprehensive code review
skills-cli / code-review --scope security

# Clean and optimize workspace
skills-cli / compact --deep-clean
```

### 3. Claude Code Integration

Once installed globally, slash commands are automatically available in Claude Code:

```bash
# Direct usage in Claude Code
/build-and-fix
/code-review --scope security
/compact
```

## Available Commands

### 🏗️ Quality Commands

#### `/build-and-fix` | `/bf` | `/build-fix`
Auto-build, lint, and fix project issues with intelligent error detection and automatic fixes.

```bash
skills-cli / build-and-fix
skills-cli / bf
```

**What it does:**
- Runs prettier for code formatting
- Executes TypeScript compilation checks
- Runs test suites with auto-fix capabilities
- Provides actionable suggestions for remaining issues

#### `/code-review` | `/cr` | `/review`
Perform comprehensive code review and analysis with security, performance, and architectural assessment.

```bash
skills-cli / code-review
skills-cli / code-review --scope security
skills-cli / cr --scope performance
```

**Available scopes:**
- `security` - Security vulnerability analysis
- `performance` - Performance bottleneck identification
- `architecture` - Architectural pattern validation
- `general` - Overall code quality assessment

### 🧹 Utilities Commands

#### `/compact` | `/clean` | `/cleanup`
Optimize workspace by cleaning cache, artifacts, and temporary files.

```bash
skills-cli / compact
skills-cli / compact --deep-clean
```

**Options:**
- `--deep-clean` - Removes all caches and temporary files

#### `/undo` | `/rollback` | `/revert`
Safely rollback recent changes with intelligent conflict resolution.

```bash
skills-cli / undo
skills-cli / undo --last-commit
```

**Options:**
- `--last-commit` - Rollback the most recent commit

#### `/plugin` | `/plug` | `/plugins`
Manage plugin system operations (install, uninstall, configure, activate, deactivate).

```bash
skills-cli / plugin list
skills-cli / plugin install @skills-fabrik/analyzer
skills-cli / plugin activate analyzer
```

### 📚 Documentation Commands

#### `/dev-docs-update` | `/ddu` | `/docs-update`
Update existing development documentation with automatic status tracking.

```bash
skills-cli / dev-docs-update feature-x --type status --status completed
skills-cli / ddu api --type review
```

**Options:**
- `--type <type>` - Documentation type (status, review, update)
- `--status <status>` - Current status (pending, in-progress, completed)

### 🧪 Testing Commands

#### `/test-route` | `/tr` | `/route-test`
Execute comprehensive automated tests on specific routes and API endpoints.

```bash
skills-cli / test-route api/users
skills-cli / test-route api/auth --method POST
skills-cli / tr api/data --timeout 5000
```

**Options:**
- `--method <method>` - HTTP method (GET, POST, PUT, DELETE, PATCH)
- `--timeout <ms>` - Request timeout in milliseconds
- `--auth <type>` - Authentication type (bearer, basic, none)

#### `/route-research-for-testing` | `/rrt` | `/route-research`
Research routes and generate comprehensive testing strategies for API endpoints.

```bash
skills-cli / route-research-for-testing api/users
skills-cli / rrt api/* --depth deep
```

**Options:**
- `--depth <level>` - Analysis depth (shallow, medium, deep)

## Claude Code Integration

Skills Fabric CLI provides native integration with Claude Code for enhanced productivity.

### Automatic Detection

When installed globally, slash commands are automatically available in Claude Code without any additional configuration.

### Usage in Claude Code

```bash
# Direct slash command usage
/build-and-fix
/code-review --scope security
/compact --deep-clean
/dev-docs-update feature-x --type status
/test-route api/users --method GET
/route-research-for-testing api/*
```

### Global Command

For universal access across any project, use the global command:

```bash
/skills-global build-and-fix
/skills-global code-review --scope security
/skills-global compact
```

## Examples

### Development Workflow

```bash
# 1. Start a new feature
skills-cli / dev-docs-update user-auth --type status --status pending

# 2. Implement with continuous quality checks
skills-cli / build-and-fix

# 3. Review code before commit
skills-cli / code-review --scope security

# 4. Test API endpoints
skills-cli / test-route api/auth --method POST

# 5. Update documentation
skills-cli / dev-docs-update user-auth --type status --status completed
```

### Code Review Pipeline

```bash
# Comprehensive security review
skills-cli / code-review --scope security

# Performance analysis
skills-cli / code-review --scope performance

# Full architectural review
skills-cli / code-review --scope architecture
```

### Workspace Maintenance

```bash
# Clean and optimize
skills-cli / compact --deep-clean

# Fix any issues
skills-cli / build-and-fix

# If something went wrong, rollback safely
skills-cli / undo --last-commit
```

### API Testing Strategy

```bash
# Research comprehensive testing approach
skills-cli / route-research-for-testing api/users

# Execute automated tests
skills-cli / test-route api/users --method GET
skills-cli / test-route api/users --method POST --auth bearer

# Test edge cases
skills-cli / test-route api/users --timeout 10000
```

## Advanced Usage

### Command Chaining

```bash
# Combine commands for complex workflows
skills-cli / build-and-fix && skills-cli / code-review
```

### Configuration

The CLI works with zero configuration, but you can customize behavior through environment variables:

```bash
export SKILLS_FABRIK_LOG_LEVEL=debug
export SKILLS_FABRIK_TIMEOUT=30000
```

### Integration with CI/CD

```yaml
# GitHub Actions example
- name: Run Skills Fabric Checks
  run: |
    skills-cli / build-and-fix
    skills-cli / code-review --scope security
```

## Troubleshooting

### Common Issues

#### Command Not Found
```bash
# Verify installation
which skills-cli

# Reinstall if needed
npm uninstall -g @skills-fabrik/skills-cli
npm install -g @skills-fabrik/skills-cli
```

#### Permission Denied
```bash
# On Unix systems, you may need to fix permissions
chmod +x $(which skills-cli)
```

#### Claude Code Commands Not Working
```bash
# Verify global installation
npm list -g @skills-fabrik/skills-cli

# Restart Claude Code after installation
```

### Debug Mode

Enable debug logging for troubleshooting:

```bash
export DEBUG=skills-cli:*
skills-cli / build-and-fix
```

### Getting Help

```bash
# List all commands
skills-cli / list

# Get help for specific command
skills-cli / build-and-fix --help

# Show system statistics
skills-cli slash stats
```

## Architecture

### Hybrid System Design

Skills Fabric CLI uses a sophisticated hybrid architecture:

1. **Workspace Mode**: When in a Skills Fabric repository, uses full workspace features
2. **Standalone Mode**: In any other project, uses lightweight standalone functionality
3. **Automatic Detection**: Seamlessly switches between modes based on context

### Command Categories

- **Quality**: Build automation, code review, security analysis
- **Utilities**: Workspace management, cleanup, rollback
- **Documentation**: Development docs, status tracking
- **Testing**: Route testing, test strategy generation

### Integration Points

- **Claude Code**: Native slash command support
- **IDE Support**: Works with any editor supporting CLI tools
- **CI/CD**: Designed for automation pipelines
- **Cross-Platform**: Windows, macOS, Linux support

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/felipe-developer/skills-fabrik.git
cd skills-fabrik/packages/skills-cli

# Install dependencies
npm install

# Run in development mode
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

## Performance

- **Startup Time**: <500ms
- **Memory Usage**: <50MB
- **Package Size**: <10MB
- **Command Execution**: Optimized for speed

## Security

- **Sandboxed Execution**: Commands run in isolated environments
- **Permission Validation**: All operations validated before execution
- **No External Dependencies**: Minimal attack surface
- **Regular Audits**: Security updates and vulnerability scanning

## License

MIT © [Skills Fabrik Team](LICENSE)

## Support

- **GitHub Issues**: [Report bugs and request features](https://github.com/felipe-developer/skills-fabrik/issues)
- **Discussions**: [Community discussions](https://github.com/felipe-developer/skills-fabrik/discussions)
- **Documentation**: [Full documentation](https://github.com/felipe-developer/skills-fabrik/wiki)

---

<div align="center">

**[Installation](#installation) • [Quick Start](#quick-start) • [Commands](#available-commands) • [Examples](#examples)**

Made with ❤️ by the Skills Fabric Team

</div>